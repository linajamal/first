First, you need to configure in your preferences:

* The map website to use for the regular maps,
* The map website to use for the route maps,
* The start address for the route maps.

Then you can use the two new buttons on the partner form to open a regular map
or a route map.
