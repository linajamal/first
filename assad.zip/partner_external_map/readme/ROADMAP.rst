* Let decide if the user prefers to use addresses instead coordinates when
  *base_geolocalize* is installed.
