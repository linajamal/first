* `Akretion <http://www.akretion.com>`__:

  * Alexis de Lattre <alexis.delattre@akretion.com>

* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Ernesto Tejeda
  * João Marques
