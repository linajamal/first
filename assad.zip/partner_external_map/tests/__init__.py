from . import test_partner_external_map
