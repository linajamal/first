# -*- coding: utf-8 -*-
# License AGPL-3
from . import fleet_vehicle