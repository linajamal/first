from odoo import api, fields, models, _
from odoo.exceptions import Warning,ValidationError
import logging
_logger = logging.getLogger(__name__)
from lxml import etree
from odoo.exceptions import UserError


class MaintenanceRequest(models.Model):
    _inherit= 'maintenance.request'




    working_hours= fields.Float(string='Total working hours')
    start_date = fields.Datetime(string='Starting date / time')
    end_date = fields.Datetime(string='End date / time')
    allowed_working_hours= fields.Float(string='Total working hours', related='equipment_id.allowed_working_hours')
    is_late = fields.Boolean(string='Late')

    def action_done(self):
        res = super(MaintenanceRequest, self).action_done()
        time_now = fields.Datetime.now()
        difference_hours = (time_now-self.create_date).days *24.0
        _logger.info('JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ')
        _logger.info(difference_hours)
        self.write({'end_date': time_now, 'working_hours':difference_hours,'is_late': True if difference_hours >self.allowed_working_hours else False})
        return res

    @api.onchange('end_date')
    def get_stock_location(self):
        self.working_hours = (self.end_date-self.create_date).days *24.0
        self.is_late = True if self.working_hours > self.allowed_working_hours else False

    def action_submit(self):
        res = super(MaintenanceRequest, self).action_submit()
        self.write({'start_date': fields.Datetime.now()})
        return res