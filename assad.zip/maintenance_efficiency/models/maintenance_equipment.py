from odoo import api, fields, models, _
from odoo.exceptions import Warning,ValidationError
import logging
_logger = logging.getLogger(__name__)
from lxml import etree
from odoo.exceptions import UserError


class MaintenanceEquipment(models.Model):
    _inherit= 'maintenance.equipment'




    allowed_working_hours= fields.Float(string='Total allowed working hours')
    