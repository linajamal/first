# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

{
    'name': "Maintenance efficiency",
    'summary': """""",
    'description': """
    """,
    'author': 'Smart Do',
    'website': 'http://www.smartdo-tech.com',
    'category': 'Generic Modules/Maintenance',
    'version': '1.0',
    'depends': ['maintenance_custom',],
    'data': [
        'views/maintenance_request.xml',
        'views/maintenance_equipment.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
